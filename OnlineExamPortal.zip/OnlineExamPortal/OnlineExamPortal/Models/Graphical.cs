﻿namespace OnlineExamPortal.Models
{
    public class Graphical
    {
        public Topic Topic { get; set; }
        public string Labels { get; set; }
        public string Data { get; set; }
        public string Colors { get; set; }

    }
}
